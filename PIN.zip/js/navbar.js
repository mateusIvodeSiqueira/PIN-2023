function link(x) {
    console.log("SIM");
    switch (x) {
        case 1:
            window.location.href = "index.html";
            break;
        case 2:
            window.location.href = "TP_trabalho.html";
            break;
        case 3:
            window.location.href = "TP_financas.html";
            break;
        case 4:
            window.location.href = "TP_SaudeMental.html";
            break;
        case 5:
            window.location.href = "TP_autocuidado.html";
            break;
        case 6:
            window.location.href = "sobreNos.html";
            break;
    }
}