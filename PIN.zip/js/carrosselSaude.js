//Resumo do subtópico 1 corresel
const texto1 = 'Dúvidas sobre a Ansiedade? Neste texto será abordado o que é a ansiedade, quais são seus sintomas, consequências, diagnósticos, seus tipos, suas fases, causas, como identificá-la e como combatê-la.';

//Resumo do subtópico 2 corresel
const texto2 = 'Dúvidas sobre o estresse? Neste texto será abordado o que é o estresse, quais são seus sintomas, seus tipos, suas fases, causas, como identificá-lo e como combatê-lo.';

//Resumo do subtópico 3 corresel
const texto3 = 'Dúvidas sobre o Isolamento Social? Neste texto será abordado temas sobre ansiedade social, quais são seus sintomas, consequências, tratamentos, medicamentos, terapia cognitivo-comportamental, terapia de exposição, entre outros.'; 

const slides = [
    {
      imgSrc: 'img/icones carrossel/SaudeMental/Icone1.png',
      text: texto1,
    },
    {
      imgSrc: 'img/icones carrossel/SaudeMental/Icone2.png',
      text: texto2,
    },
    {
      imgSrc: 'img/icones carrossel/SaudeMental/Icone3.png',
      text: texto3,
    },
  ];
  
  const imgElement = document.getElementById('carousel-img');
  const textElement = document.getElementById('carousel-text');
  const menuButtons = document.querySelectorAll('.menu-button');
  const carouselContainer = document.querySelector('.carousel');
  
  let currentIndex = 1;
  
  function changeSlide(index) {
    if (index === currentIndex) {
      return;
    }
  
    carouselContainer.classList.add('slide-up');
  
    setTimeout(() => {
      imgElement.style.opacity = 0;
      textElement.style.opacity = 0;
  
      setTimeout(() => {
        imgElement.src = slides[index].imgSrc;
        textElement.textContent = slides[index].text;
  
        menuButtons[currentIndex].classList.remove('active');
        menuButtons[index].classList.add('active');
  
        currentIndex = index;
  
        imgElement.style.opacity = 1;
        textElement.style.opacity = 1;
        carouselContainer.classList.remove('slide-up');
      }, 500);
    }, 500);
  }
  
  menuButtons.forEach((button, index) => {
    button.addEventListener('click', () => {
      changeSlide(index);
    });
  });
  
  // Initial slide
  changeSlide(0);

  //Vai iniciar com o primeiro slide e ao clicar vai ser o próximo
  fetch("/arquivosTexto/SaudeMental"+ currentIndex + ".txt")
        .then(res=>res.text())
        .then(res=> {
          document.getElementById("elemento").innerHTML = res;
      document.getElementById("tituloLermais").textContent = document.getElementById("btnSub"+currentIndex).textContent
      })

  //Esse aqui ao clicar
  function mudarTexto(num) {
    fetch("/arquivosTexto/SaudeMental"+ num + ".txt")
    .then(res=>res.text())
    .then(res => {
      document.getElementById("elemento").innerHTML = res;
      document.getElementById("tituloLermais").textContent = document.getElementById("btnSub"+num).textContent
    })
}