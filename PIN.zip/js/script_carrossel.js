var selected;
var conter;

function clicou(x) {
    selected = x;
    conter = selected;
    //Fiz assim para caso precisarmos utilizar os valores separados / Também para entendermos melhor o que ocorre no codigo
}
    setInterval (function (){
        if (conter < 4){
    
            if(document.getElementById("slide1").checked = true) {
                conter++;
                document.getElementById('slide' + conter).checked =  true;
            }

            else if (document.getElementById('slide2').checked = true) {
                conter++;
                document.getElementById('slide' + conter).checked =  true;
            }
    
            else if (document.getElementById('slide3').checked = true) {
                conter++;
                document.getElementById('slide' + conter).checked =  true;
            }
        }
        else{
            conter = 1;
            document.getElementById('slide' + conter).checked =  true;
        }
        
        
        /* console.log("Valor: ", selected.value);
    
        console.log(conter);
    
        console.log(document.getElementById('slide' + conter).checked); */
    
    }, 3000);