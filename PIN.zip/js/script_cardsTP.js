var button = document.getElementById('btn_lerMais');

button.addEventListener('click', function() {
    var card = document.querySelector('.card');
    card.classList.toggle('active');

    if(card.classList.contains('active')) {
        return button.textContent = 'Ler Menos -';
    }

        return button.textContent = 'Ler Mais +';

});