//Resumo do subtópico 1 corresel
const texto1 = 'Dúvidas sobre como interpretar as contas de luz? Nesse texto explicamos os principais pontos e termos presentes na fatura de energia.';

//Resumo do subtópico 2 corresel
const texto2 = 'Tem curiosidade de saber o que é o consumo consciente ou tem dúvidas de como trazer essa prática para sua vida, nesse texto explicaremos o que ele é como adotar algumas medidas.';

//Resumo do subtópico 3 corresel
const texto3 = 'Não sabe como funciona os descontos por atraso e por falta no seu trabalho? Talvez este texto responda suas dúvidas!';

//Resumo do subtópico 4 corresel
const texto4 = 'Dúvidas sobre o FGTS e para que serve? Nesse texto explicaremos o que ele é, para que serve, quem tem direito e como consultar esse benefício. ';

//Resumo do subtópico 5 corresel
const texto5 = 'Dúvidas sobre o que é o INSS ou para que ele serve? Nesse texto explicaremos o que ele é, os serviços disponíveis e como acessar a plataforma digital desse órgão governamental. '; 

//Resumo do subtópico 6 corresel
const texto6 = 'Dúvidas sobre o fundo de emergência? Este texto talvez responda suas dúvidas! Aqui você encontrará o que é, para quê serve e como criar um fundo de emergência. '; 

//Resumo do subtópico 7 corresel
const texto7 = 'Dúvidas sobre o IPTU? Neste texto falaremos sobre o que é o IPTU, como ele é calculado e como funciona o pagamento do mesmo. '; 

//Resumo do subtópico 8 corresel
const texto8 = 'Dúvidas sobre Imposto de renda ou imposto de renda retido da fonte? Nesse texto explicaremos o que é, quem deve pagar e quem é isento e o que é a restituição do imposto de renda'; 

//Resumo do subtópico 9 corresel
const texto9 = 'O planejamento financeiro é uma ação extremamente importante para aqueles que desejam uma vida financeira saudável. Aqui você encontrará o que é o planejamento financeiro e dicas sobre o assunto. '; 

//Resumo do subtópico 10 corresel
const texto10 = 'Dúvidas sobre o IPVA? Neste texto falaremos sobre o que é o IPVA, como ele é calculado e como funciona o pagamento o seu pagamento. '; 

const slides = [
    {
      imgSrc: 'img/icones carrossel/Financeiro/Icone1.png',
      text: texto1,
    },
    {
      imgSrc: 'img/icones carrossel/Financeiro/Icone2.png',
      text: texto2,
    },
    {
      imgSrc: 'img/icones carrossel/Financeiro/Icone3.png',
      text: texto3,
    },
    {
      imgSrc: 'img/icones carrossel/Financeiro/Icone4.png',
      text: texto4,
    },
    {
      imgSrc: 'img/icones carrossel/Financeiro/Icone5.png',
      text: texto5,
    },
    {
      imgSrc: 'img/icones carrossel/Financeiro/Icone6.png',
      text: texto6,
    },
    {
      imgSrc: 'img/icones carrossel/Financeiro/Icone7.png',
      text: texto7,
    },
    {
      imgSrc: 'img/icones carrossel/Financeiro/Icone8.png',
      text: texto8,
    },
    {
      imgSrc: 'img/icones carrossel/Financeiro/Icone9.png',
      text: texto9,
    },
    {
      imgSrc: 'img/icones carrossel/Financeiro/Icone10.png',
      text: texto10,
    },
  ];
  
  const imgElement = document.getElementById('carousel-img');
  const textElement = document.getElementById('carousel-text');
  const menuButtons = document.querySelectorAll('.menu-button');
  const carouselContainer = document.querySelector('.carousel');
  
  let currentIndex = 1;
  
  function changeSlide(index) {
    if (index === currentIndex) {
      return;
    }
  
    carouselContainer.classList.add('slide-up');
  
    setTimeout(() => {
      imgElement.style.opacity = 0;
      textElement.style.opacity = 0;
  
      setTimeout(() => {
        imgElement.src = slides[index].imgSrc;
        textElement.textContent = slides[index].text;
  
        menuButtons[currentIndex].classList.remove('active');
        menuButtons[index].classList.add('active');
  
        currentIndex = index;
  
        imgElement.style.opacity = 1;
        textElement.style.opacity = 1;
        carouselContainer.classList.remove('slide-up');
      }, 500);
    }, 500);
  }
  
  menuButtons.forEach((button, index) => {
    button.addEventListener('click', () => {
      changeSlide(index);
    });
  });
  
  // Initial slide
  changeSlide(0);

  //Vai iniciar com o primeiro slide e ao clicar vai ser o próximo
  fetch("/arquivosTexto/Financeiro" + currentIndex + ".txt")
        .then(res=>res.text())
        .then(res=> {
          document.getElementById("elemento").innerHTML = res;
      document.getElementById("tituloLermais").textContent =  document.getElementById("btnSub"+currentIndex).textContent
      })

  //Esse aqui ao clicar
  function mudarTexto(num) {
  fetch("/arquivosTexto/Financeiro" + num + ".txt")
    .then(res=>res.text())
    .then(res => {
      document.getElementById("elemento").innerHTML = res;
      document.getElementById("tituloLermais").textContent =  document.getElementById("btnSub"+num).textContent
    })
}