//Resumo do subtópico 1 corresel
const texto1 = 'Aqui você encontrará dicas sobre organização do seu autocuidado.';

//Resumo do subtópico 2 corresel
const texto2 = 'Esse tema irá te ajudar a manter uma rotina de autocuidado, fazendo com que se torne uma parte primordial do seu dia.';

//Resumo do subtópico 3 corresel
const texto3 = 'Aqui, você aprenderá sobre o que é produtividade tóxica, que te ajudará a reconhecer melhor quais são seus limites.';

//Resumo do subtópico 4 corresel
const texto4 = 'O que são pontos de refúgio? Para que servem? Como saber qual o meu? Aqui você saberá mais sobre isso.';

//Resumo do subtópico 5 corresel
const texto5 = 'Aqui, você encontrará dicas sobre como manter uma rotina de autocuidado mesmo em tempos complicados, com técnicas para ajustar sua rotina de autocuidado.';  

const slides = [
    {
      imgSrc: 'img/icones carrossel/AutoCuidado/Icone1_Como organizar meu autocuidado.png',
      text: texto1,
    },
    {
      imgSrc: 'img/icones carrossel/AutoCuidado/Icone2_Mantendo a rotina de Autocuidado.png',
      text: texto2,
    },
    {
      imgSrc: 'img/icones carrossel/AutoCuidado/Icone3_Pontos de refúgio como música arte jogos livros entre outros no autocuidado.png',
      text: texto3,
    },
    {
      imgSrc: 'img/icones carrossel/AutoCuidado/Icone4_Praticando uma rotina de autocuidado mesmo em dias difíceis.png',
      text: texto4,
    },
    {
      imgSrc: 'img/icones carrossel/AutoCuidado/Icone5_Produtividade tóxica.png',
      text: texto5,
    },
  ];
  
  const imgElement = document.getElementById('carousel-img');
  const textElement = document.getElementById('carousel-text');
  const menuButtons = document.querySelectorAll('.menu-button');
  const carouselContainer = document.querySelector('.carousel');
  
  let currentIndex = 1;
  
  function changeSlide(index) {
    if (index === currentIndex) {
      return;
    }
  
    carouselContainer.classList.add('slide-up');
  
    setTimeout(() => {
      imgElement.style.opacity = 0;
      textElement.style.opacity = 0;
  
      setTimeout(() => {
        imgElement.src = slides[index].imgSrc;
        textElement.textContent = slides[index].text;
  
        menuButtons[currentIndex].classList.remove('active');
        menuButtons[index].classList.add('active');
  
        currentIndex = index;
  
        imgElement.style.opacity = 1;
        textElement.style.opacity = 1;
        carouselContainer.classList.remove('slide-up');
      }, 500);
    }, 500);
  }
  
  menuButtons.forEach((button, index) => {
    button.addEventListener('click', () => {
      changeSlide(index);
    });
  });
  
  // Initial slide
  changeSlide(0);

  //Vai iniciar com o primeiro slide e ao clicar vai ser o próximo
    fetch("/arquivosTexto/AutoCuidado"+ currentIndex + ".txt")
        .then(res=>res.text())
        .then(res => {
          document.getElementById("elemento").innerHTML = res;
          document.getElementById("tituloLermais").textContent = document.getElementById("btnSub"+currentIndex).textContent
        })
        
  //Esse aqui ao clicar
  function mudarTexto(num) {
    fetch("/arquivosTexto/AutoCuidado"+ num + ".txt")
        .then(res=>res.text())
        .then(res => {
          document.getElementById("elemento").innerHTML = res;
          document.getElementById("tituloLermais").textContent = document.getElementById("btnSub"+num).textContent
        })
  }
