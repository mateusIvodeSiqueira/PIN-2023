//Resumo do subtópico 1 corresel
const texto1 = 'O currículo é sua porta de entrada para oportunidades profissionais. Neste texto, abordaremos como criar um currículo eficaz, destacando suas habilidades e experiências de maneira atraente para potenciais empregadores.';

//Resumo do subtópico 2 corresel
const texto2 = 'Na busca por oportunidades profissionais, a entrevista é um momento crítico. Neste artigo, discutiremos como se comportar adequadamente durante esse encontro para maximizar suas chances de sucesso.';

//Resumo do subtópico 3 corresel
const texto3 = 'Sua conduta em um ambiente profissional é crucial para o sucesso. Neste texto, abordaremos as diretrizes essenciais para uma postura adequada no trabalho.';

//Resumo do subtópico 4 corresel
const texto4 = ' A saúde no trabalho é crucial. Neste texto, exploraremos como promover um ambiente de trabalho saudável, abordando bem-estar mental no trabalho.';

const slides = [
    {
      imgSrc: 'img/icones carrossel/Trabalho/Icone1.png',
      text: texto1,
    },
    {
      imgSrc: 'img/icones carrossel/Trabalho/Icone4.png',
      text: texto2,
    },
    {
      imgSrc: 'img/icones carrossel/Trabalho/Icone3.png',
      text: texto3,
    },
    {
      imgSrc: 'img/icones carrossel/Trabalho/Icone5.png',
      text: texto4,
    },

  ];
  
  const imgElement = document.getElementById('carousel-img');
  const textElement = document.getElementById('carousel-text');
  const menuButtons = document.querySelectorAll('.menu-button');
  const carouselContainer = document.querySelector('.carousel');
  
  let currentIndex = 1;
  
  function changeSlide(index) {
    if (index === currentIndex) {
      return;
    }
  
    carouselContainer.classList.add('slide-up');
  
    setTimeout(() => {
      imgElement.style.opacity = 0;
      textElement.style.opacity = 0;
  
      setTimeout(() => {
        imgElement.src = slides[index].imgSrc;
        textElement.textContent = slides[index].text;
  
        menuButtons[currentIndex].classList.remove('active');
        menuButtons[index].classList.add('active');
  
        currentIndex = index;
  
        imgElement.style.opacity = 1;
        textElement.style.opacity = 1;
        carouselContainer.classList.remove('slide-up');
      }, 500);
    }, 500);
  }
  
  menuButtons.forEach((button, index) => {
    button.addEventListener('click', () => {
      changeSlide(index);
    });
  });
  
  // Initial slide
  changeSlide(0);

  //Vai iniciar com o primeiro slide e ao clicar vai ser o próximo
  fetch("/arquivosTexto/Trabalho"+ currentIndex + ".txt")
        .then(res=>res.text())
        .then(res=> {
          document.getElementById("elemento").innerHTML = res;
      document.getElementById("tituloLermais").textContent = document.getElementById("btnSub"+currentIndex).textContent
      })

  //Esse aqui ao clicar
  function mudarTexto(num) {
  fetch("/arquivosTexto/Trabalho"+ num + ".txt")
    .then(res=>res.text())
    .then(res => {
      document.getElementById("elemento").innerHTML = res;
      document.getElementById("tituloLermais").textContent = document.getElementById("btnSub"+num).textContent
    })
}